//
//  HelpshiftX.h
//  HelpshiftX
//
//  Copyright © 2019 Helpshift. All rights reserved.
//

#import <UIKit/UIKit.h>

// ! Project version number for HelpshiftX.
FOUNDATION_EXPORT double HelpshiftXVersionNumber;

// ! Project version string for HelpshiftX.
FOUNDATION_EXPORT const unsigned char HelpshiftXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelpshiftX/PublicHeader.h>

#import "Helpshift.h"
